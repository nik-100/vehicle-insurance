package com.lnt.mvc.controller;


import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.lnt.mvc.model.VehicleDetails;
import com.lnt.mvc.service.IVehicleService;






@Controller
public class VehicleController {
	
	private IVehicleService iVehicleService;

	@Autowired
	public void setiVehicleService(IVehicleService vs) {
		this.iVehicleService = vs;
	}



	
		
	
	@RequestMapping(value="/vehicles")
	public String listVehicleDetails(Model model) {
		List<String>array=new ArrayList<>();
		array.add("Suzuki");
		array.add("Maruti");
		model.addAttribute("vehicle", new VehicleDetails());
		model.addAttribute("Brandlist", array);
/*		model.addAttribute("listVehicleDetails",this.iVehicleService.listVehicleDetails());*/
		return "vehicle";
	}
	
	@RequestMapping(value = "/vehicles/add",method = RequestMethod.POST)
/*	@ExceptionHandler({ CustomException.class })*/
	public String addVehicle(
			@ModelAttribute("vehicle") 
			@Valid VehicleDetails v, 
			BindingResult result, 
			Model model) {
		if(!result.hasErrors())
		{
			this.iVehicleService.addVehicle(v);	
		}
			
	/*	model.addAttribute("listVehicleDetails", this.iVehicleService.listVehicleDetails());*/
		return "redirect:/vehicle";
		
		
	
		
		
		

	}
	


	}
	
