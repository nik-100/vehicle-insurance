package com.lnt.mvc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;



//@Component
@Entity
@Table(name="VEHICLEDETAILS")
public class VehicleDetails implements Serializable {
	
	@Id
		private Integer vehicleId;
	@Column
	private String  brand;
	@Column
	private String model;
	@Column
	//@NotEmpty(message = " License number must be of 13 digits")
	private int license;
	//@NotEmpty(message = " Year must be in 4 digits")
	@Column
	private int mfgYear;
	@Column
	private int regNumber;
	@Column
	private int engineNum;
	@Column
	private int ChasisNum;
	
	
	public VehicleDetails() {
		super();
		}


	@Override
	public String toString() {
		return "Vehicle [vehicleId=" + vehicleId + ", brand=" + brand + ", model=" + model + ", license=" + license
				+ ", mfgYear=" + mfgYear + ", regNumber=" + regNumber + ", engineNum=" + engineNum + ", ChasisNum="
				+ ChasisNum + "]";
	}


	public Integer getVehicleId() {
		return vehicleId;
	}


	public void setVehicleId(Integer vehicleId) {
		this.vehicleId = vehicleId;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	public int getLicense() {
		return license;
	}


	public void setLicense(int license) {
		this.license = license;
	}


	public int getMfgYear() {
		return mfgYear;
	}


	public void setMfgYear(int mfgYear) {
		this.mfgYear = mfgYear;
	}


	public int getRegNumber() {
		return regNumber;
	}


	public void setRegNumber(int regNumber) {
		this.regNumber = regNumber;
	}


	public int getEngineNum() {
		return engineNum;
	}


	public void setEngineNum(int engineNum) {
		this.engineNum = engineNum;
	}


	public int getChasisNum() {
		return ChasisNum;
	}


	public void setChasisNum(int chasisNum) {
		ChasisNum = chasisNum;
	}

}






