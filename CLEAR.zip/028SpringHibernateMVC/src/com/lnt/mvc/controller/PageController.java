package com.lnt.mvc.controller;


import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.lnt.mvc.model.UserDetails;
import com.lnt.mvc.model.VehicleDetails;
import com.lnt.mvc.service.UserService;



@Controller
public class PageController {
	
	private UserService userService;

	@Autowired
	public void setUserService(UserService ps) {
		this.userService = ps;
	}
	
	
	@RequestMapping(value="/users")
	public String listVehicleDetails(Model model) {

		model.addAttribute("user", new VehicleDetails());
		
		return "user";
	}
	

	@RequestMapping(value="/users/add" ,method = RequestMethod.POST)
		public String addUser(@ModelAttribute("user") UserDetails u,BindingResult result, Model model) {

		if (!result.hasErrors()) {			
					this.userService.addUser(u);
			}  
		 
			return "usersuccess";
	}
	
}
