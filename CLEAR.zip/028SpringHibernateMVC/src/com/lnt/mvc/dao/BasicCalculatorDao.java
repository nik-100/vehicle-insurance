package com.lnt.mvc.dao;

import com.lnt.mvc.model.BasicCalculator;


public interface BasicCalculatorDao {
	public void addBasicCal (BasicCalculator b);

}
