package com.lnt.mvc.dao;

import com.lnt.mvc.model.Plans;

public interface PlansDao {
	
	 public void addPlan (Plans p);

}
