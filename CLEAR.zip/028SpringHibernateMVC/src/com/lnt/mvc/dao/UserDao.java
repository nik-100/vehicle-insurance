package com.lnt.mvc.dao;



import com.lnt.mvc.model.UserDetails;


public interface UserDao {
	
	public void addUser(UserDetails u);
	
}
