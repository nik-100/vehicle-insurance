package com.lnt.mvc.model;


import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.executable.ValidateOnExecution;


@Entity
@Table(name="BasicCalculator")
public class BasicCalculator {

		 @OneToOne(mappedBy = "tempBasicCal", cascade = CascadeType.ALL)
		private ApplicationInsurance applicationInsurance;
		
		@Id
		@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="basicCal_seq")
		@SequenceGenerator(name="basicCal_seq", sequenceName="basicCal_seq")
		private Integer calId;
		 
		
		@Column
		private String calModel;
		@Column
		private int calPurchaseMonth;
		@Column
		private int calPurchaseYear;
		
		@Override
		public String toString() {
			return "BasicCalculator [applicationInsurance=" + applicationInsurance + ", calId=" + calId + ", calModel="
					+ calModel + ", calPurchaseMonth=" + calPurchaseMonth + ", calPurchaseYear=" + calPurchaseYear
					+ "]";
		}

		public BasicCalculator() {
			super();
		
		}


	
}
