package com.lnt.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.lnt.mvc.dao.BasicCalculatorDao;
import com.lnt.mvc.model.BasicCalculator;

public class BasicCalculatorServiceImpl implements IBasicCalculatorService {

	@Autowired
	private BasicCalculatorDao basicCalculatorDao;
	
	public BasicCalculatorDao getBasicCalculatorDao() {
		return basicCalculatorDao;
	}


	public void setBasicCalculatorDao(BasicCalculatorDao basicCalculatorDao) {
		this.basicCalculatorDao = basicCalculatorDao;
	}
	
	
	@Override
	public void addBasicCal(BasicCalculator b) {
		// TODO Auto-generated method stub
		this.basicCalculatorDao.addBasicCal(b);
	}


}
