package com.lnt.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.lnt.mvc.dao.ClaimDao;
import com.lnt.mvc.model.Claim;

public class ClaimServiceImpl implements IClaimService {

	@Autowired
	private ClaimDao claimDao;
	
	public ClaimDao getClaimDao() {
		return claimDao;
	}


	public void setClaimDao(ClaimDao claimDao) {
		this.claimDao = claimDao;
	}


	@Override
	public void addClaimDetails(Claim c) {
		// TODO Auto-generated method stub
		this.claimDao.addClaimDetails(c);
	}





}
