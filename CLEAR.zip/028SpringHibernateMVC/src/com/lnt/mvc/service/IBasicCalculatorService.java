package com.lnt.mvc.service;

import com.lnt.mvc.model.BasicCalculator;

public interface IBasicCalculatorService {

	public void addBasicCal (BasicCalculator b);

	
}
