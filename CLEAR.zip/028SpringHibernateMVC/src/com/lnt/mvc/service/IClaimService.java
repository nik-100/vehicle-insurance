package com.lnt.mvc.service;

import com.lnt.mvc.model.Claim;

public interface IClaimService {
	
	 public void addClaimDetails(Claim c);

}
