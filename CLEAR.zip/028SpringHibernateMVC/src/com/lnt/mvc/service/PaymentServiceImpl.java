package com.lnt.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.lnt.mvc.dao.PaymentDao;
import com.lnt.mvc.model.Payment;

public class PaymentServiceImpl implements PaymentServiceDao{

	@Autowired
	private PaymentDao paymentDao;
	
	public PaymentDao getPaymentDao() {
		return paymentDao;
	}

	public void setPaymentDao(PaymentDao paymentDao) {
		this.paymentDao = paymentDao;
	}

	@Override
	public void addPayment(Payment p) {
		// TODO Auto-generated method stub
		this.paymentDao.addPayment(p);
		
	}
}
