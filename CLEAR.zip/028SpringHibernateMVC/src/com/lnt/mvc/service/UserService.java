package com.lnt.mvc.service;

import org.springframework.stereotype.Service;

import com.lnt.mvc.model.UserDetails;


public interface UserService {
	public void addUser(UserDetails u);
		
}
