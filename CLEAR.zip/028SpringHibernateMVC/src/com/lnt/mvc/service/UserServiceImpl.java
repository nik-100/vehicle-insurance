package com.lnt.mvc.service;



import org.springframework.beans.factory.annotation.Autowired;


import com.lnt.mvc.dao.UserDao;
import com.lnt.mvc.model.UserDetails;

public class UserServiceImpl implements UserService{
	
	@Autowired
		private UserDao userDao;
	//setter method for personDao


		public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}


		public void addUser(UserDetails u) {
			this.userDao.addUser(u);
		}


}


