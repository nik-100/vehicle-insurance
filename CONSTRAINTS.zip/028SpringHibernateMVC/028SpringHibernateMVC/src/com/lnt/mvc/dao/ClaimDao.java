package com.lnt.mvc.dao;

import com.lnt.mvc.model.Claim;

public interface ClaimDao {
	
	 public void addClaimDetails(Claim c);

}
