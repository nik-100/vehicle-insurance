package com.lnt.mvc.dao;

import com.lnt.mvc.model.VehicleDetails;

public interface VehicleDAO {

	
	 public void addVehicle (VehicleDetails v);


}
