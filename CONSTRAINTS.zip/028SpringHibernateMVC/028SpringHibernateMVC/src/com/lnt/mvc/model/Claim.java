package com.lnt.mvc.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="CLAIM")
public class Claim implements Serializable {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@OneToOne(mappedBy="tempClaim", cascade = CascadeType.ALL)
	 	private ApplicationInsurance applicationInsurance;
	
	@OneToOne(cascade = CascadeType.ALL)
 	private Plans plans;
	
	@OneToOne(cascade = CascadeType.ALL)
	private Payment payment;
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="claim_seq")
	@SequenceGenerator(name="claim_seq", sequenceName="claim_seq")
	private Integer claimId;
	private String claimDate;
	private String claimReason;
	
	
	
	
	
	
	public ApplicationInsurance getApplicationInsurance() {
		return applicationInsurance;
	}



	public void setApplicationInsurance(ApplicationInsurance applicationInsurance) {
		this.applicationInsurance = applicationInsurance;
	}



	public Plans getPlans() {
		return plans;
	}



	public void setPlans(Plans plans) {
		this.plans = plans;
	}



	public Payment getPayment() {
		return payment;
	}



	public void setPayment(Payment payment) {
		this.payment = payment;
	}



	public Integer getClaimId() {
		return claimId;
	}



	public void setClaimId(Integer claimId) {
		this.claimId = claimId;
	}



	public String getClaimDate() {
		return claimDate;
	}



	public void setClaimDate(String claimDate) {
		this.claimDate = claimDate;
	}



	public String getClaimReason() {
		return claimReason;
	}



	public void setClaimReason(String claimReason) {
		this.claimReason = claimReason;
	}



	public String getClaimStatus() {
		return claimStatus;
	}



	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}







	@Override
	public String toString() {
		return "Claim [applicationInsurance=" + applicationInsurance + ", plans=" + plans + ", payment=" + payment
				+ ", claimId=" + claimId + ", claimDate=" + claimDate + ", claimReason=" + claimReason
				+ ", claimStatus=" + claimStatus + "]";
	}



	private String claimStatus;
	
	
     
	public Claim() {
		super();

	}
		
}
