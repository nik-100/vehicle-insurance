package com.lnt.mvc.service;

import com.lnt.mvc.model.ApplicationInsurance;

public interface IApplicationInsuranceService {

	public double calculatePremium(ApplicationInsurance applicationInsurance);
	 public double displayClaimDetails(ApplicationInsurance applicationInsurance);
	 public int displayPlanId(ApplicationInsurance applicationInsurance);;
}
