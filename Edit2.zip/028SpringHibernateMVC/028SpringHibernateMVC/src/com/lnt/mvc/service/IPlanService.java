package com.lnt.mvc.service;

import com.lnt.mvc.model.Plans;

public interface IPlanService {
	
	 public void addPlan (Plans p);
}
