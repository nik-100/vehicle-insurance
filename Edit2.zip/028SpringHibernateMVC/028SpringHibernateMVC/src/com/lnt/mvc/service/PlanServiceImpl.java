package com.lnt.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.lnt.mvc.dao.PlansDao;
import com.lnt.mvc.model.Plans;

public class PlanServiceImpl implements IPlanService{
	@Autowired
	PlansDao planDao;

	public void setPlanDao(PlansDao planDao) {
		this.planDao = planDao;
	}
	
	@Override
	public void addPlan(Plans p) {

		this.planDao.addPlan(p);
		
		
	}



}
