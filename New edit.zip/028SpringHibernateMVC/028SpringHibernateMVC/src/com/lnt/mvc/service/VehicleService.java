package com.lnt.mvc.service;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.mvc.dao.VehicleDAO;
import com.lnt.mvc.model.VehicleDetails;


//@Service
public class VehicleService implements IVehicleService {
	@Autowired
	VehicleDAO vehicleDao;


public void setVehicleDao(VehicleDAO vehicleDao) {
	this.vehicleDao = vehicleDao;
}



@Override
	public void addVehicle(VehicleDetails v) {
		// TODO Auto-generated method stub
	this.vehicleDao.addVehicle(v);
	}

/*@Override
@Transactional
	public List<VehicleDetails> listVehicleDetails() {
		// TODO Auto-generated method stub
return	this.vehicleDao.listVehicleDetails();
	}*/

/*@Override
@Transactional
	public Vehicle ListVehiclebyId(int id) {
		// TODO Auto-generated method stub
		return this.vehicleDao.ListVehiclebyId(id);
	}
*/
	
}
