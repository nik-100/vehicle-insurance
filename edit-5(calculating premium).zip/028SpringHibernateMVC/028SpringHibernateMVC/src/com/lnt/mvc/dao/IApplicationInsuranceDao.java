package com.lnt.mvc.dao;

import com.lnt.mvc.model.ApplicationInsurance;

public interface IApplicationInsuranceDao {

	public double calculatePremium(ApplicationInsurance applicationInsurance);
}
