package com.lnt.mvc.dao;

import com.lnt.mvc.model.Payment;


public interface PaymentDao {
	
	 public void addPayment (Payment p);

}
