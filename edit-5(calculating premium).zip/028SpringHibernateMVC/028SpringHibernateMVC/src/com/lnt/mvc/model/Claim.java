package com.lnt.mvc.model;

public class Claim {

}
