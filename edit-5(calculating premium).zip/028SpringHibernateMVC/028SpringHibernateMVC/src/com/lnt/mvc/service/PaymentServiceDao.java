package com.lnt.mvc.service;

import com.lnt.mvc.model.Payment;

public interface PaymentServiceDao {
	 public void addPayment (Payment p);

}
