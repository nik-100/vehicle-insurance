package com.lnt.mvc.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="plans")

public class Plans {
	
	@OneToOne(mappedBy = "plans")
	private VehicleDetails vehicleDetails;
	@Id
	private int planId;
	//@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="plan_seq")

	private String planType;
	
	
	@Override
	public String toString() {
		return "Plans [planId=" + planId + ", planType=" + planType + "]";
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public String getPlanType() {
		return planType;
	}
	public void setPlanType(String planType) {
		this.planType = planType;
	}

	
}
