package com.lnt.mvc.service;


import com.lnt.mvc.model.VehicleDetails;


public interface IVehicleService {
	 public void addVehicle (VehicleDetails v);
	 //public List<VehicleDetails> listVehicleDetails();
	/* public Vehicle ListVehiclebyId(int id);*/


}
