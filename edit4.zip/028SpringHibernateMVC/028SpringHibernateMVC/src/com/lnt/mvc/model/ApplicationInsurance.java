package com.lnt.mvc.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="ApplicationInsurance")
public class ApplicationInsurance {
	
	@Id
		private int applicationId;
	
	
	@OneToOne(cascade=CascadeType.ALL)
	private VehicleDetails tempVehicle;
	
	@OneToOne(cascade=CascadeType.ALL)
	private Plans tempPlan;

	
	
	
	
	
	public ApplicationInsurance() {
		super();
 
	}

	public int getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public VehicleDetails getTempVehicle() {
		return tempVehicle;
	}

	public void setTempVehicle(VehicleDetails tempVehicle) {
		this.tempVehicle = tempVehicle;
	}

	public Plans getTempPlan() {
		return tempPlan;
	}

	public void setTempPlan(Plans tempPlan) {
		this.tempPlan = tempPlan;
	}
	
	
	

}
