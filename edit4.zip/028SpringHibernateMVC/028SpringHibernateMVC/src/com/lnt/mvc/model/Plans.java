package com.lnt.mvc.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="plans")

public class Plans {
	
	@OneToOne(mappedBy="plans", cascade = CascadeType.ALL)
	private VehicleDetails vehicleDetails;
	@Id
	private int planId;
	//@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="plan_seq")

	private String planType;
	private int planYear;
	
	
	public int getPlanYear() {
		return planYear;
	}
	public void setPlanYear(int planYear) {
		this.planYear = planYear;
	}
	
	
	
	@Override
	public String toString() {
		return "Plans [vehicleDetails=" + vehicleDetails + ", planId=" + planId + ", planType=" + planType
				+ ", planYear=" + planYear + "]";
	}
	public int getPlanId() {
		return planId;
	}
	public void setPlanId(int planId) {
		this.planId = planId;
	}
	public String getPlanType() {
		return planType;
	}
	public void setPlanType(String planType) {
		this.planType = planType;
	}
	public Plans() {
		super();
	
	}

	

}
