package com.lnt.mvc.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.lnt.mvc.dao.IApplicationInsuranceDao;
import com.lnt.mvc.model.ApplicationInsurance;

public class ApplicationServiceImpl implements IApplicationInsuranceService{
	
	@Autowired
private IApplicationInsuranceDao iApplicationInsuranceDao;
	
	public void setiApplicationInsuranceDao(IApplicationInsuranceDao iApplicationInsuranceDao) {
		this.iApplicationInsuranceDao = iApplicationInsuranceDao;
	}



	@Override
	public double calculatePremium(ApplicationInsurance applicationInsurance) {
		// TODO Auto-generated method stub
		
		return this.iApplicationInsuranceDao.calculatePremium(applicationInsurance);
	
	}
}
