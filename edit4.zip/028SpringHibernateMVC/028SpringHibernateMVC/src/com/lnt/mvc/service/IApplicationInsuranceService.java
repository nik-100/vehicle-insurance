package com.lnt.mvc.service;

import com.lnt.mvc.model.ApplicationInsurance;

public interface IApplicationInsuranceService {

	public double calculatePremium(ApplicationInsurance applicationInsurance);
}
