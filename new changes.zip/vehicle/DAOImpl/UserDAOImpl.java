package com.lti.vehicle.DAOImpl;

	import java.util.Iterator;
	import java.util.List;

	import org.hibernate.Query;
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.Transaction;
	import org.slf4j.Logger;
	import org.slf4j.LoggerFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Repository;

import com.lti.vehicle.dao.UserDao;
import com.lti.vehicle.model.UserDetails;


	@Repository("userDAO")
	 
	public class UserDAOImpl implements UserDao {
		private static final Logger logger = 			
				LoggerFactory.getLogger(UserDAOImpl.class);
		
	 

	 
		Transaction tx;
		@Autowired
		private SessionFactory sessionFactory;
		public void setSessionFactory(SessionFactory sf) {
			this.sessionFactory = sf;
		}


//		@Override
//		public String getByEmail(String email) {
//			//String selectQuery = "FROM User WHERE email = :email";
//			String password=null;
//			 Transaction trns = null;
//	         Session session = this.sessionFactory.openSession();
//	          trns = session.beginTransaction();
//	          System.out.println(email);
//	          Query query = session.createQuery("select password from User u  where u.email=:email");
//	         
//	          query.setParameter("email", email);
//	          
//	          List<String> passwords =  query.list();
//	         Iterator iterator = query.iterate();
//	         
//	         while(iterator.hasNext())
//	         {
//	        	  password =  (String)iterator.next();
//	        	 
//	         }
//	         System.out.println(password);
//	         
//	         return  password;
	//   }

								
		

		@Override
		public void addUser(UserDetails u) {
			Session session = this.sessionFactory.openSession();
			tx = session.beginTransaction();
			session.save(u);
			tx.commit();
			session.close();
			logger.info("User details saved successfully, User Details="+ u);
		}


	/*@Override
		public UserDetails get(int id) {
			try {			
				return (UserDetails) sessionFactory.getCurrentSession().get(UserDetails.class, id);			
			}
			catch(Exception ex) {
				System.out.println(ex.getMessage());
				return null;
			}
			
		}*/
		
		
		
	@Override
	public boolean verifyUser(String email, String password) {
		Session session = this.sessionFactory.openSession();
		 tx=session.beginTransaction();
		 System.out.println("this is emai;"+email);
		 System.out.println("this is pass;"+password);
		  String query="select email, password from UserDetails u where u.email=:email and u.password=:password";	
		  Query q=session.createQuery(query);
 		q.setString("email",email);
		  q.setString("password",password);

			  List<UserDetails> l=q.list();
			  if(l.size()==0)
			  {
				  System.out.println("Invalid User");
			    return false;
			  }
			  System.out.println("Verified User");
			 tx.commit(); 
		  session.close();
		  return true;


	}


	/*@Override
	public UserDetails getByEmail(String email) {
   		Session session=this.sessionFactory.openSession();
		tx=session.beginTransaction();
		System.out.println(email);
		Query query=session.createQuery("from UserDetails u where u.email=:email");
		List <UserDetails> userList=query.list();
		
		tx.commit();
		session.close();
		if(userList.size()>0)
		{
			System.out.println("user lis"+userList);
			return  userList.get(0);
		}
		else {
		return null;		
			}
			}*/
	
	public UserDetails getByEmail(String email) {
		Session session = this.sessionFactory.openSession();
		String query = "from UserDetails u where u.email=:email";
		Query q = session.createQuery(query);
		 q.setString("email", email);
		
		  List<UserDetails> l=q.list();

		if (l.size() == 0) {
			return null;
		}
		UserDetails userDetails = (UserDetails) l.get(0);
		session.close();
		return userDetails;
	}
	}


	
