package com.lti.vehicle.dao;

import com.lti.vehicle.model.Claim;

public interface ClaimDao {
	
	 public void addClaimDetails(Claim c);

}
