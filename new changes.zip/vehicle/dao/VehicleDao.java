package com.lti.vehicle.dao;

import com.lti.vehicle.model.VehicleDetails;

public interface VehicleDao {

	
	 public void addVehicle (VehicleDetails v);
/*	 public List<VehicleDetails> listVehicleDetails();*/
	 VehicleDetails getVehicleById(Integer vehicleId);

}
