package com.lti.vehicle.service;

import com.lti.vehicle.model.ApplicationInsurance;

public interface IApplicationInsuranceService {

	public double calculatePremium(ApplicationInsurance applicationInsurance);
	 public double displayClaimDetails(ApplicationInsurance applicationInsurance);
	 public int displayPlanId(ApplicationInsurance applicationInsurance);;
}
