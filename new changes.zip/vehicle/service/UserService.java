package com.lti.vehicle.service;

	import org.springframework.stereotype.Service;

import com.lti.vehicle.model.UserDetails;
	@Service
	public interface UserService {
		
		void addUser(UserDetails u);
		boolean verifyUser(String email, String password);
		UserDetails getByEmail(String email);

			
	}
